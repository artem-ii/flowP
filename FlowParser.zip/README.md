<h1>FlowP</h1>
<h3>FlowP is an R script for automatic transformation of flow cytometry data table exported from FlowJo into a nice looking report.</h3>

* File pops.txt represents an input file, in which all the parameters for analysis are set.
* funcs.R contains functions
* FlowParser.R contains data import script and calls main function.
